/*********************
Joshua Kennerly
CPSC 2310 Fall 2020
jdkenne
Dr. Feaster
**********************/
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>

int printReturn(int a, int b, int action);

#endif